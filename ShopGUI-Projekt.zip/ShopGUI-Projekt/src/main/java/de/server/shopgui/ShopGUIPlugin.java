package de.server.shopgui;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;
import java.util.stream.Collectors;

public final class ShopGUIPlugin extends JavaPlugin implements Listener, CommandExecutor {
    private Economy economy;
    private NamespacedKey actionKey, materialKey;

    private static final String[] CATEGORIES = {"Blöcke", "Erze & Mineralien", "Holz & Pflanzen", "Essen"};
    private static final Material[] CATEGORY_ICONS = {
        Material.GRASS_BLOCK, Material.DIAMOND, Material.OAK_SAPLING, Material.COOKED_BEEF
    };

    @Override public void onEnable() {
        saveDefaultConfig();
        actionKey = new NamespacedKey(this, "aktion");
        materialKey = new NamespacedKey(this, "material");
        if (!setupEconomy()) {
            getLogger().severe("Kein Vault-Economy-Anbieter gefunden. Bitte EssentialsX Economy oder einen anderen Vault-kompatiblen Anbieter aktivieren.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        getServer().getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("shop")).setExecutor(this);
        Objects.requireNonNull(getCommand("sellall")).setExecutor(this);
        getLogger().info("ShopGUI wurde aktiviert.");
    }

    private boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) return false;
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) return false;
        economy = rsp.getProvider();
        return economy != null;
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("shop")) {
            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                if (!sender.hasPermission("shopgui.admin")) { sender.sendMessage(color("&cDafür hast du keine Berechtigung.")); return true; }
                reloadConfig(); sender.sendMessage(color("&aShop-Konfiguration neu geladen.")); return true;
            }
            if (!(sender instanceof Player p)) { sender.sendMessage("Dieser Befehl ist nur im Spiel verfügbar."); return true; }
            openMain(p); return true;
        }
        if (command.getName().equalsIgnoreCase("sellall")) {
            if (!(sender instanceof Player p)) { sender.sendMessage("Dieser Befehl ist nur im Spiel verfügbar."); return true; }
            sellAll(p); return true;
        }
        return true;
    }

    private void openMain(Player p) {
        Inventory inv = Bukkit.createInventory(null, 27, color(getConfig().getString("einstellungen.menue-titel", "&6&lSERVER-SHOP")));
        fillBorder(inv);
        for (int i=0;i<CATEGORIES.length;i++) {
            ItemStack item = named(CATEGORY_ICONS[i], "&e&l" + CATEGORIES[i], List.of("&7Klicke, um die Kategorie zu öffnen."));
            setAction(item, "cat:" + i);
            inv.setItem(10+i*2, item);
        }
        inv.setItem(22, named(Material.GOLD_INGOT, "&6Dein Kontostand", List.of("&e" + money(economy.getBalance(p)) )));
        p.openInventory(inv);
    }

    private void openCategory(Player p, int category, int page) {
        Inventory inv = Bukkit.createInventory(null, 54, color("&8Shop: &6" + CATEGORIES[category]));
        fillBorder(inv);
        List<Material> materials = materialsFor(category);
        int start = page * 28;
        int end = Math.min(start + 28, materials.size());
        int slot = 10;
        for (int i=start;i<end;i++) {
            Material mat = materials.get(i);
            double price = getConfig().getDouble("preise." + mat.name(), 0);
            ItemStack item = new ItemStack(mat);
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(color("&f" + pretty(mat)));
            List<String> lore = new ArrayList<>();
            lore.add(color("&7Kauf: &a" + money(price)));
            lore.add(color("&7Verkauf: &c" + money(price * getConfig().getDouble("einstellungen.verkauf-multiplikator", .5))));
            lore.add(color("&eLinksklick: 1 kaufen"));
            lore.add(color("&eRechtsklick: 1 verkaufen"));
            lore.add(color("&6Shift-Klick: 64 Stück"));
            meta.setLore(lore);
            meta.getPersistentDataContainer().set(actionKey, PersistentDataType.STRING, "item");
            meta.getPersistentDataContainer().set(materialKey, PersistentDataType.STRING, mat.name());
            item.setItemMeta(meta);
            inv.setItem(slot, item);
            slot++;
            if (slot == 17 || slot == 26 || slot == 35 || slot == 44) slot += 2;
        }
        if (page > 0) inv.setItem(45, actionItem(Material.ARROW, "&eVorherige Seite", "page:"+(page-1)+":"+category));
        if (end < materials.size()) inv.setItem(53, actionItem(Material.ARROW, "&eNächste Seite", "page:"+(page+1)+":"+category));
        inv.setItem(49, actionItem(Material.BARRIER, "&cZurück zum Hauptmenü", "home"));
        p.openInventory(inv);
    }

    private List<Material> materialsFor(int category) {
        return Arrays.stream(Material.values()).filter(Material::isItem)
            .filter(m -> m != Material.AIR && getConfig().getDouble("preise."+m.name(), 0) > 0)
            .filter(m -> switch(category) {
                case 0 -> isBlock(m);
                case 1 -> containsAny(m.name(), "ORE", "INGOT", "RAW_", "DIAMOND", "EMERALD", "COAL", "REDSTONE", "LAPIS", "QUARTZ", "AMETHYST", "COPPER");
                case 2 -> containsAny(m.name(), "LOG", "WOOD", "PLANKS", "SAPLING", "LEAVES", "FLOWER", "TULIP", "ROSE", "DAISY", "SEEDS", "SUGAR_CANE", "CACTUS", "BAMBOO", "VINE", "FERN", "MOSS", "LILY_PAD");
                case 3 -> m.isEdible();
                default -> false;
            }).sorted(Comparator.comparing(Material::name)).collect(Collectors.toList());
    }

    private boolean isBlock(Material m) {
        return m.isBlock() && !containsAny(m.name(), "ORE", "LOG", "WOOD", "PLANKS", "LEAVES", "SAPLING", "FLOWER", "TULIP", "ROSE", "DAISY", "FERN", "MOSS");
    }
    private boolean containsAny(String s, String... bits) { for (String b:bits) if (s.contains(b)) return true; return false; }

    @EventHandler public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        String title = ChatColor.stripColor(e.getView().getTitle());
        if (title == null || !(title.equals("SERVER-SHOP") || title.startsWith("Shop:"))) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;
        ItemStack clicked = e.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) return;
        ItemMeta meta = clicked.getItemMeta();
        String action = meta.getPersistentDataContainer().get(actionKey, PersistentDataType.STRING);
        if (action == null) return;
        if (action.startsWith("cat:")) { openCategory(p, Integer.parseInt(action.substring(4)), 0); return; }
        if (action.equals("home")) { openMain(p); return; }
        if (action.startsWith("page:")) {
            String[] parts=action.split(":"); openCategory(p,Integer.parseInt(parts[2]),Integer.parseInt(parts[1])); return;
        }
        if (action.equals("item")) {
            Material mat = Material.matchMaterial(meta.getPersistentDataContainer().get(materialKey, PersistentDataType.STRING));
            if (mat == null) return;
            int amount = e.isShiftClick() ? 64 : 1;
            if (e.isLeftClick()) buy(p, mat, amount);
            else if (e.isRightClick()) sell(p, mat, amount);
            int category = categoryOf(mat);
            if (category >= 0) openCategory(p, category, 0);
        }
    }

    private int categoryOf(Material m) { for (int c=0;c<4;c++) if (materialsFor(c).contains(m)) return c; return -1; }
    private void buy(Player p, Material m, int amount) {
        double price = getConfig().getDouble("preise."+m.name(),0) * getConfig().getDouble("einstellungen.kauf-multiplikator",1) * amount;
        if (price <= 0) { p.sendMessage(color("&cDieser Gegenstand kann nicht gekauft werden.")); return; }
        if (economy.getBalance(p) < price) { p.sendMessage(color("&cDu hast nicht genug Geld.")); return; }
        if (p.getInventory().firstEmpty() == -1 && p.getInventory().contains(m)) { p.sendMessage(color("&cDein Inventar ist voll.")); return; }
        economy.withdrawPlayer(p, price);
        Map<Integer, ItemStack> left = p.getInventory().addItem(new ItemStack(m, amount));
        left.values().forEach(item -> p.getWorld().dropItemNaturally(p.getLocation(), item));
        p.sendMessage(color("&aGekauft: &f"+amount+"x "+pretty(m)+" &afür &e"+money(price)));
    }
    private void sell(Player p, Material m, int amount) {
        double unit = getConfig().getDouble("preise."+m.name(),0) * getConfig().getDouble("einstellungen.verkauf-multiplikator",.5);
        if (unit <= 0) { p.sendMessage(color("&cDieser Gegenstand kann nicht verkauft werden.")); return; }
        int have = count(p,m), actual = Math.min(amount,have);
        if (actual <= 0) { p.sendMessage(color("&cDu hast diesen Gegenstand nicht im Inventar.")); return; }
        remove(p,m,actual); double total=unit*actual; economy.depositPlayer(p,total);
        p.sendMessage(color("&aVerkauft: &f"+actual+"x "+pretty(m)+" &afür &e"+money(total)));
    }
    private void sellAll(Player p) {
        double total=0; int count=0;
        for (Material m: Material.values()) {
            double unit=getConfig().getDouble("preise."+m.name(),0)*getConfig().getDouble("einstellungen.verkauf-multiplikator",.5);
            if (unit<=0) continue;
            int n=count(p,m); if(n>0){remove(p,m,n);total+=unit*n;count+=n;}
        }
        if(count==0){p.sendMessage(color("&eDu hast keine verkaufbaren Shop-Gegenstände im Inventar."));return;}
        economy.depositPlayer(p,total);
        p.sendMessage(color("&aDu hast &f"+count+" Gegenstände &afür &e"+money(total)+" &averkauft."));
    }
    private int count(Player p, Material m) { int n=0; for(ItemStack it:p.getInventory().getStorageContents()) if(it!=null&&it.getType()==m)n+=it.getAmount(); return n; }
    private void remove(Player p, Material m, int amount) {
        int remaining=amount;
        for(int i=0;i<p.getInventory().getStorageContents().length&&remaining>0;i++){
            ItemStack it=p.getInventory().getItem(i);
            if(it==null||it.getType()!=m)continue;
            int take=Math.min(remaining,it.getAmount()); it.setAmount(it.getAmount()-take);
            if(it.getAmount()<=0)p.getInventory().setItem(i,null);
            remaining-=take;
        }
    }
    private ItemStack actionItem(Material m,String name,String action){ItemStack i=named(m,name,List.of());setAction(i,action);return i;}
    private ItemStack named(Material m,String name,List<String> lore){ItemStack i=new ItemStack(m);ItemMeta meta=i.getItemMeta();meta.setDisplayName(color(name));meta.setLore(lore.stream().map(ShopGUIPlugin::color).toList());i.setItemMeta(meta);return i;}
    private void setAction(ItemStack i,String action){ItemMeta meta=i.getItemMeta();meta.getPersistentDataContainer().set(actionKey,PersistentDataType.STRING,action);i.setItemMeta(meta);}
    private void fillBorder(Inventory inv){ItemStack glass=named(Material.BLACK_STAINED_GLASS_PANE,"&8 ",List.of());for(int i=0;i<inv.getSize();i++)if(i<9||i>=inv.getSize()-9||i%9==0||i%9==8)inv.setItem(i,glass);}
    private String pretty(Material m){String s=m.name().toLowerCase(Locale.ROOT).replace('_',' ');StringBuilder b=new StringBuilder();for(String w:s.split(" "))b.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1)).append(' ');return b.toString().trim();}
    private String money(double n){return String.format(Locale.GERMAN,"%.2f %s",n,getConfig().getString("einstellungen.waehrung","$"));}
    private static String color(String s){return ChatColor.translateAlternateColorCodes('&',s==null?"":s);}
}
