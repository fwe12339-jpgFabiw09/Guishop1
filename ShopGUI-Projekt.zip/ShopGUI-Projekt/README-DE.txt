SHOPGUI – INSTALLATION (DEUTSCH)
================================

WICHTIG ZUR VERSION
Dieses Projekt ist für Paper 26.2 und Java 25 eingestellt. Paper 26.2 benötigt Java 25.
Die hier bereitgestellte Datei ist das vollständige Quellprojekt, noch keine fertige .jar.
Zum Bauen wird Gradle mit JDK 25 und Internetzugang benötigt.

VORAUSSETZUNGEN
- Paper 26.2
- Java 25
- Vault
- Ein Vault-kompatibler Economy-Anbieter (z. B. EssentialsX Economy)
- Gradle (oder eine IDE wie IntelliJ IDEA mit Gradle-Unterstützung)

PLUGIN BAUEN
1. Installiere JDK 25.
2. Entpacke den Ordner ShopGUI-Projekt.
3. Öffne diesen Ordner in IntelliJ IDEA als Gradle-Projekt.
4. Warte, bis Gradle die Abhängigkeiten geladen hat.
5. Führe den Gradle-Task "build" aus.
6. Die fertige Datei liegt danach unter:
   build/libs/ShopGUI-1.0.0.jar

AUF DEM SERVER INSTALLIEREN
1. Stoppe den Paper-Server vollständig.
2. Erstelle zur Sicherheit eine Kopie deines Serverordners bzw. mindestens der Welt- und Plugin-Daten.
3. Kopiere ShopGUI-1.0.0.jar in den Ordner "plugins".
4. Stelle sicher, dass Vault UND ein Economy-Anbieter (z. B. EssentialsX mit Economy-Modul) ebenfalls im Ordner "plugins" liegen.
5. Starte den Server neu.
6. Beim ersten Start erstellt ShopGUI die Datei plugins/ShopGUI/config.yml.
7. Im Spiel öffnest du den Shop mit /shop.
8. Mit /sellall verkaufst du alle Gegenstände, die in der Shop-Konfiguration einen Verkaufspreis haben.
9. Preise bearbeitest du in plugins/ShopGUI/config.yml. Danach /shop reload (als Admin).

BEDIENUNG
- Linksklick auf einen Gegenstand: 1 Stück kaufen.
- Rechtsklick: 1 Stück verkaufen.
- Shift + Linksklick: 64 Stück kaufen.
- Shift + Rechtsklick: bis zu 64 Stück verkaufen.
- Verkaufspreise sind standardmäßig 50 % des Kaufpreises.

HINWEIS ZU ESSENTIALS
Vault ist nur die Schnittstelle. Es muss zusätzlich ein Economy-Plugin aktiv sein, das Vault einen Economy-Dienst bereitstellt. EssentialsX allein ohne Economy-Modul reicht nicht.
